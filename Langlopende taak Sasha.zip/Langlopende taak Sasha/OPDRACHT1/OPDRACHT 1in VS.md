www.gamegeneratie.be
----------------------------------------------------------------------------------------------------------------
Homepage* 

Sfeerbeeld: beknopte uitleg over de site, GG--GAMEGENERATIE


Homepagepic.jpg

-----------------------------------------------------------------------------------------------------------------
OVERZICHTSPAGINA:

6 topics over gamen:
GAME INDUSTRIE
*Meer info over de recente evoluties in de gameindustrien,Esports teams opgelijst*
foto: game industrie overzicht
PC
*Welke soorten games spelen we allemaal op pc*
foto: steam overzicht
CONSOLES
*Welke consoles zijn er (geweest)?*
foto: console overzicht
MOBA GAMES
*1 van mijn favoriete moba games:league of legends, nader toegelicht*
foto:moba overzicht
SPORT GAMES
*De populairste sportgame die al jaren meedraaid: FIFA* 
foto: fifa 2023 overzicht
SHOOTERS
*Zowel op pc als console zijn shooters hot, dewelke ken jij?*
foto:shooter overzicht

----------------------------------------------------------------------------------------------------------------
[Topic pg1]
Titel topic: Gameindustrie
Ondertitel: De evolutie van de laatste jaren

Online games hebben de afgelopen jaren een enorme evolutie doorgemaakt. Met de opkomst van technologie en internetverbindingen van hogere kwaliteit zijn online games steeds populairder geworden. Deze evolutie heeft geleid tot veranderingen in zowel de gameplay als de manier waarop mensen met elkaar communiceren en concurreren.

De laatste jaren is er ook nog de mobiele game industrie bijgekomen maar de voorbije jaren maar voorheen kon men al kiezen of men wou spelen op *PC* of op een *console* zoals onder andere playstation en Xbox. 
   (*hyperlink*tekst klik naar juiste pagina op site)
Een van de meest opvallende veranderingen in online games is de verschuiving van singleplayer-ervaringen naar multiplayer-ervaringen. Vroeger waren games voornamelijk gericht op het spelen tegen computergestuurde tegenstanders. Nu hebben spelers de mogelijkheid om online te spelen met andere mensen van over de hele wereld. Dit heeft geleid tot een geheel nieuwe dimensie van competitie en samenwerking. Spelers kunnen nu hun vaardigheden meten tegen echte tegenstanders en sociale interactie hebben met andere spelers.

Een andere belangrijke ontwikkeling is de opkomst van eSports. Dit zijn professionele competities waarin getalenteerde spelers het tegen elkaar opnemen in verschillende online games. eSports zijn uitgegroeid tot een miljardenindustrie met grote toernooien en prijzengelden.
            
De game-industrie is afgelopen jaren enorm gegroeid en heeft een ongekend niveau van populariteit bereikt. Het is uitgegroeid tot een van de grootste en meest winstgevende entertainmentindustrieën ter wereld. De omvang van de hiervan wordt niet alleen gemeten in termen van het aantal spelers, maar ook in de enorme hoeveelheid geld die erin omgaat.

Lijst: *Lijst met 20 ESPORTS teams en opbrengsten van tornooien*
*bron:https://www.esportsearnings.com/teams*
1.	Team Liquid	    $47,527,336.37	2620 Tournaments
2.	OG	            $38,064,532.44	170 Tournaments
3.	Evil Geniuses	$28,470,559.56	998 Tournaments
4.	Team Spirit 	$27,360,465.40	222 Tournaments
5.	Natus Vincere	$20,779,480.99	709 Tournaments
6.	Team Secret	    $20,199,189.44	392 Tournaments
7.	Fnatic	        $20,062,410.35	1113 Tournaments
8.	PSG Esports 	$19,104,571.91	158 Tournaments
9.	Virtus.pro  	$18,944,854.55	627 Tournaments
10.	FaZe Clan	    $16,994,826.76	676 Tournaments
11.	Vici Gaming	    $15,676,109.59	313 Tournaments
12.	Invictus Gaming	$15,077,405.31	624 Tournaments
13.	LGD Gaming	    $14,757,706.17	201 Tournaments
14.	G2 Esports	    $14,678,317.69  678 Tournaments
15.	Newbee	        $14,230,154.91	236 Tournaments
16.	Cloud9	        $13,464,985.91	982 Tournaments
17.	T1	            $13,302,607.26  480 Tournaments
18.	eStar Gaming	$12,104,168.53	107 Tournaments
19.	Team SoloMid	$11,689,610.65	948 Tournaments
20.	OpTic Gaming	$11,671,624.30	408 Tournaments

Figure:game industrie growth
----------------------------------------------------------------------------------------------------------------
[Topic pg2]
Titel topic: PC
Ondertitel:Gamen op PC
Gamen op de pc is een populaire en boeiende activiteit die vele mensen over de hele wereld aantrekt. Met de steeds evoluerende technologieën en de krachtige hardware die beschikbaar is, biedt de pc een ongeëvenaarde game-ervaring. Of je nu een casual gamer bent of een hardcore gamer, er zijn talloze games beschikbaar om op de computer te spelen. Persoonlijk verkies ik de PC boven de console maar die mening verschilt van gamer tot gamer.

Daarnaast heeft de PC de game-industrie toegankelijker gemaakt voor een breder publiek. Door de opkomst van digitale distributieplatforms zoals Steam en GOG.com kunnen gamers eenvoudig games downloaden en installeren op hun PC. Dit heeft de drempel verlaagd voor zowel ontwikkelaars als spelers, omdat het niet langer nodig is om fysieke verkooppunten te vinden die jou spel nog heeft liggen of voor de ontwikkelaar zou willen verkopen.

Een van de meest geliefde genres onder pc-gamers is het first-person *shooter* (FPS) genre. Deze games vereisen strategisch denken, snelle reflexen en teamwork om te kunnen winnen.      (*hyperlink* tekst met link naar pagina)
Voor degenen die graag hun creativiteit willen uiten, zijn er games zoals "Minecraft" en "The Sims". In "Minecraft" kunnen spelers hun eigen wereld bouwen en verkennen, terwijl "The Sims" hen in staat stelt om virtuele personages te creëren en hun leven te beheren. Deze games bieden een ontspannende en verbeeldingsrijke ervaring.

Zo zijn er nog verschillende soorten pc-games die hieronder opgelijst worden.

Lijst:
-Role Playing Games
-Massively Multiplayer Online Role Playing Games (MMORPG)
-Real-time Strategy Games (RTS)
*-Multiplayer Online Battle Arena (MOBA)* (*hyperlink* tekst met link naar pagina)
*-First Person Shooters (FPS)* (*hyperlink* tekst met link naar pagina)
-Adventure Games
*-Sport Game* (*hyperlink* tekst met link naar pagina)
-Simulatiegames
-Casual games 


Figure:  Game platforms pc top 
----------------------------------------------------------------------------------------------------------------
[Topic pg3]
Titel topic: Consoles
Ondertitel: Geschiedenis van de console
In de beginjaren van gaming waren consoles eenvoudige apparaten met beperkte mogelijkheden. De eerste populaire gameconsole, de Magnavox Odyssey, werd in 1972 uitgebracht en bood eenvoudige spellen zoals Pong en Tennis. Deze spellen hadden simpele graphics en waren meestal zwart-wit.

Naarmate de technologie vorderde, werden consoles steeds geavanceerder. De release van de Atari 2600 in 1977 markeerde een keerpunt in de game-industrie. Deze console bood kleurengraphics en cartridge-gebaseerde spellen, waardoor spelers een breder scala aan spellen konden ervaren.

In de jaren '80 en '90 werden consoles zoals de Nintendo Entertainment System (NES) en de Sega Genesis enorm populair. Deze consoles introduceerden geavanceerdere graphics en geluid, waardoor spelers een meer meeslepende ervaring kregen.

De laatste jaren hebben we een aantal opmerkelijke ontwikkelingen gezien op het gebied van game consoles. Deze nieuwe generatie consoles heeft de manier waarop we gamen veranderd en heeft ons meegenomen naar een geheel nieuwe dimensie van entertainment. Laten we eens kijken naar enkele van de meest recente ontwikkelingen.

Een van de meest opvallende consoles die onlangs is uitgebracht, is de PlayStation 5. Deze console, ontwikkeld door Sony, heeft gamers over de hele wereld enthousiast gemaakt. Met zijn krachtige hardware en indrukwekkende grafische mogelijkheden biedt de PlayStation 5 een ongeëvenaarde game-ervaring.

Lijst:*Lijst van alle consoles tem laatste playstation en Xbox*

Eerste generatie (1972-1980)

    Atari Pong (speelhalversie: 1972, thuisversie: 1975)
    Magnavox Odyssey (1972)
        Magnavox Odyssey 100 (1975)
        Magnavox Odyssey 200 (1976)
    Philips Telespel ES2201 (1975)
    Coleco Telstar (1976)
    APF TV Fun (1976)
    Color TV Game (1977)
    Zanussi Ping-O-Tronic (1974)

Tweede generatie (1976-1982)

    RCA Studio II (1976)
    Fairchild Channel F (1976)
    Bally Astrocade (1977)
    Atari 2600 (1977)
    Magnavox Odyssey²/Philips Videopac G7000 (1978)
    Interton VC4000 (1978)
    APF Imagination Machine (1979)
    Mattel Intellivision (1980)
    VTech CreatiVision (1981)
    GCE Vectrex (1982)
    Emerson Arcadia 2001 (1982)
    Atari 5200 (1982)
    Coleco ColecoVision (1982)
    Sega SG-1000 (1983)

Derde generatie van 8 bitstijdperk (1983-2003)

    PV-1000 (1983, alleen in Japan)
    Epoch Cassette Vision (1984, alleen in Japan)
    Nintendo Entertainment System (1985)
    Atari 7800 (1986)
    Sega Mark III (1985, alleen in Japan)
        Sega Master System (1986)
    Supergame VG 3000 (1985, alleen in Japan)
    Atari XEGS (1987)
    Amstrad GX4000 (1990)
    Commodore 64 Games System (1990)

Vierde generatie van 16 bitstijdperk (1987-2004)

    Sega Mega Drive (1989, in Amerika als Sega Genesis)
        Sega Mega-CD (1992)
        Sega 32X (1994)
    SNK Neo-Geo (1990)
        SNK Neo-Geo CD (1994)
    Super Nintendo Entertainment System (1991)

Vijfde generatie van 32/64 bitstijdperk (1993-2006)

    Atari Panther (1991, niet uitgebracht)
    Commodore Amiga CD32 (1993)
    3DO (1993)
    Atari Jaguar (1993) (64 bit)
        Atari Jaguar CD (1995)
    Sega Saturn (1994)
    Sony PlayStation (1995)
    Nintendo 64 (1996) (64 bit)
        Nintendo 64DD (1999, alleen in Japan)


Zesde generatie van 128 bitstijdperk (1998-2013)

    Sega Dreamcast (1999)
    Sony PlayStation 2 (2000)
    Microsoft Xbox (2001)
    Nintendo GameCube (2001)
    Panasonic Q (2001)


Zevende generatie (2004-2017)

    Xbox 360 (2005)
        Xbox 360 S (2010)
    Wii (2006)
    PlayStation 3 (2007)
        PlayStation 3 Slim (2009)

Achtste generatie (2011-2019)

    Wii U (2012)
    Wii Mini (2012)
    Ouya (2013)
    PlayStation 4 (2013)
        PlayStation 4 Slim (2016)
        PlayStation 4 Pro (2016)
    Xbox One (2013)
        Xbox One S (2016)
        Xbox One X (2017)
    PlayStation TV (2014)
    Nintendo Switch (2017)

Negende generatie (2020-heden)

    PlayStation 5 (2020)
    Xbox Series (2020)
    Nintendo Switch Oled (2021)
    Atari VCS (2021)

Figure: games-consoles
Semantische tabel met consoles en uitgifte data
( met bijschrift) 
----------------------------------------------------------------------------------------------------------------
[Topic pg4]
Titel topic:  MOBA GAMES
Ondertitel:League of legends
League of Legends is een online multiplayer spel dat wordt gespeeld door miljoenen mensen over de hele wereld.  Het is een zogenaamd MOBA (Multiplayer Online Battle Arena) spel, waarbij twee teams van vijf spelers het tegen elkaar opnemen in een virtuele arena. Deze game is uitsluitend voor PC (*hyperlink* tekst met link naar pagina)

Het doel van het spel is om de basis van de tegenstander te vernietigen, die wordt beschermd door verdedigingstorens en vijandelijke spelers. Elk team heeft een eigen basis, waarin ze hun personages, ook wel "champions" genoemd, kunnen verbeteren en nieuwe vaardigheden kunnen ontgrendelen naarmate het spel vordert.

Elke speler kiest een champion waarmee ze willen spelen, en elke champion heeft unieke vaardigheden en speelstijlen. Het is belangrijk om strategisch samen te werken met je teamgenoten om de tegenstander te verslaan, omdat elke champion een specifieke rol heeft binnen het team, zoals een aanvaller, verdediger of ondersteuner.

Tijdens het spel kunnen spelers ervaringspunten en goud verdienen door vijandelijke minions en champions te doden. Met dit goud kunnen ze items kopen om hun champion sterker te maken en hen te helpen tijdens de gevechten.
Er zijn verschillende gamemodes maar de bekendste en diegende waar ook de Esport rond draait is summoners rift 5V5 
Deze games duren telkens tussen de 20 en 45 minuten per spel afhankelijk van hoe gelijk het op gaat. 

Lijst: ROLES 
-TOP
-MID
-JUNGLE
-BOTTOM
-SUPPORT 

De nieuwere gamemode TFT staat voor Teamfight Tactics, wat een strategisch spel is dat is gebaseerd op het League of Legends-universum. Deze is ook mobiel te spelen. In dit spel bouw je een team van kampioenen op en neem je het op tegen andere spelers in een tactische strijd. Het doel is om je team zo te positioneren en uit te rusten dat ze de tegenstanders verslaan. Je moet slimme beslissingen nemen over welke kampioenen je verzamelt, welke items je ze geeft en hoe je ze opstelt in het gevecht. Elke ronde worden er nieuwe kampioenen beschikbaar gesteld en kun je je team aanpassen om de beste strategie te vinden en de overwinning te behalen. TFT is een uitdagend en verslavend spel dat zowel geluk als strategie vereist. Je speelt het alleen tegen 7 tegenstanders.




Figure: league map 
----------------------------------------------------------------------------------------------------------------

[Topic pg5]
Titel topic: Sport games
Ondertitel:FIFA

1 van mijn all time favorite sportspellen blijft FIFA, dit speel ik het liefst op playstation maar nu de laatste jaren de controllers voor PC en crossplay tussen console en PC mogelijk is maakt het niet zo veel verschil meer. 
FIFA is een populaire videospelserie die wordt ontwikkeld door EA Sports. Het staat voor "Fédération Internationale de Football Association" en is gebaseerd op het wereldwijde voetbal. In het spel kun je teams en spelers van over de hele wereld beheren en besturen, en deelnemen aan verschillende competities en toernooien. FIFA-spellen worden elk jaar vernieuwd en bijgewerkt met nieuwe functies, spelers en teams. Het is beschikbaar op verschillende platforms, waaronder consoles, pc en mobiele apparaten.

Het biedt een realistische voetbalervaring met gedetailleerde graphics, realistische spelersbewegingen en geluidseffecten. Het kan een leuke manier zijn om jezelf onder te dompelen in de wereld van voetbal. FIFA biedt verschillende spelmodi, waaronder online multiplayer, waar je kunt strijden tegen andere spelers over de hele wereld. Dit kan een geweldige manier zijn om je vaardigheden te testen en te verbeteren.

Tegenwoordig hebben alle grote sportclubs ook hun Esports team dat hun vertegenwoordigt. 

Elke speler en elk team hebben quoteringen zoals ook de rangschikking in de echte voetbalwereld.
Hieronder een lijst met de best gequoteerde spelers op FIFA 2023


Lijst:
Beste spelers op de FIFA game lijst
Rank 	Player Name 	Nationality 	Club 	Position 	Player Rating
01 	Karim Benzema   	France  	Real Madrid 	CF 	        91
02 	Robert Lewandowski 	Poland  	FC Barcelona 	ST 	        91
03 	Kylian Mbappe   	France 	    PSG 	        ST 	        91
04 	Kevin De Bruyne 	Belgium 	Manchester City CM 	        91
05 	Lionel Messi    	Argentina 	PSG 	        RW 	        91
06 	Mohamed Salah   	Egypt   	Liverpool 	    RW 	        90
07 	Virgil Van Dijk 	Holland 	Liverpool   	CB 	        90
08 	Cristiano Ronaldo 	Portugal 	Manchester Utd 	ST 	        90
09 	Thibaut Courtois 	Belgium 	Real Madrid 	GK 	        90
10 	Manuel Neuer 	    Germany 	FC Bayern Mun   GK 	        90
11 	Neymar JR 	        Brazil 	    PSG         	LW 	        89
12 	Heung Min Son   	Korea   	Tottenham   	LW 	        89
13 	Sadio Mane 	        Senegal 	FC Bayern Mun	LM 	        89
14 	Joshua Kimmich  	Germany 	FC Bayern Mun	CDM 	    89
15 	Casemiro 	        Brazil  	Manchester Utd	CDM 	    89
16 	Alisson 	        Brazil  	Liverpool 	    GK 	        89
17 	Harry Kane      	England 	Tottenham   	ST 	        89
18 	Ederson 	        Brazil 	    Manchester Cty	GK 	        89
19 	N'Golo Kante 	    France 	    Chelsea 	    CDM 	    89
20 	Jan Oblak 	        Slovenia 	Atletico Madrid GK 	        89

Ons land is toch mooi vertegenwoordigd met 2 plaatsen in de top 10: Kevin De Bruyne en Thibault Courtois



Figure: fifa player picture
----------------------------------------------------------------------------------------------------------------
[Topic pg6]
Titel topic: SHOOTERS
Ondertitel: Is crossplay fair bij FPS (shooters)
De mogelijkheid van spelers om samen spelen op verschillende platformen (pc,playstation,...), heet crossplay en is een onderwerp dat vaak wordt besproken in de wereld van first-person shooter (FPS) games. Of crossplay eerlijk is bij FPS games hangt af van verschillende factoren.

Een van de belangrijkste factoren is het verschil in inputmethoden. Spelers op pc maken vaak gebruik van een toetsenbord en muis, terwijl spelers op consoles meestal een controller gebruiken. Het is algemeen bekend dat het spelen met een toetsenbord en muis een nauwkeurigere en snellere controle kan bieden in vergelijking met een controller. Dit kan een oneerlijk voordeel opleveren voor pc-spelers ten opzichte van console-spelers.

Daarnaast kunnen er ook verschillen zijn in de prestaties van de hardware. Pc's hebben over het algemeen krachtigere hardware dan consoles, waardoor pc-spelers mogelijk een betere grafische kwaliteit, hogere framesnelheden en kortere laadtijden hebben.
Sommige shooters implementeren daarom crossplay met beperkingen, zoals het scheiden van spelers op basis van het platform dat ze gebruiken of het toestaan van spelers om crossplay in- en uit te schakelen. Dit kan helpen om de speelervaring eerlijker te maken.
Of misschien moeten de consoles het mogelijk maken er een toetsenbord op aan te sluiten? Hoewel dit de laatste jaren meer en meer gelijk getrokken is zal het toch een discusie blijven. 

Hierbij een lijst met veel gespeelde shooters
Lijst:

-Valorant
-Destiny 2
-Escape from Tarkov
-Apex Legends
-Splitgate
-Call of Duty: Warzone 2.0
-Counter strike global offensive

Figure: vergelijk Xbox en pc
----------------------------------------------------------------------------------------------------------------
Contactpagina:
Contact admin en contact webdesigner


----------------------------------------------------------------------------------------------------------------
Opzoekwerk API:
https://www.freetogame.com/api-doc
https://www.freetogame.com/api/games?category=shooter
te gebruiken op shooter pagina
(uitbreiden, eventueel andere api zoeken)

----------------------------------------------------------------------------------------------------------------

Verschil in sites is groot, veel basic sites met info. De sites van de gameplatformen en proffesionele gamesites zijn wel heel goed uitgewerkt. 

Verschillende kleuren, sommige simpel witte achtergrond. 


Evaluatie:
-Zelf gekleurde achtergrond gebruiken met complementerende kleur als letterkleur
-Pagina's goed structureren
-plaatsbepaling van alle input is belangrijk om interesse hoog te houden 
-
